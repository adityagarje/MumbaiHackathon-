import React, { useState } from 'react';
import { Send, User, Calendar, FileText, History } from 'lucide-react';

interface PatientData {
  name: string;
  age: string;
  symptoms: string;
  medicalHistory: string;
}

interface SymptomFormProps {
  onSubmit: (data: PatientData) => void;
}

export function SymptomForm({ onSubmit }: SymptomFormProps) {
  const [formData, setFormData] = useState<PatientData>({
    name: '',
    age: '',
    symptoms: '',
    medicalHistory: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const formFields = [
    {
      icon: User,
      name: 'name',
      label: 'Patient Name',
      type: 'text',
      placeholder: 'Enter patient name',
      required: true
    },
    {
      icon: Calendar,
      name: 'age',
      label: 'Age',
      type: 'number',
      placeholder: 'Enter age',
      required: true
    }
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {formFields.map(({ icon: Icon, name, label, type, placeholder, required }) => (
          <div key={name} className="space-y-1">
            <label htmlFor={name} className="flex items-center text-sm font-medium text-gray-700">
              <Icon className="h-4 w-4 mr-2" />
              {label}
            </label>
            <input
              type={type}
              id={name}
              name={name}
              value={formData[name as keyof PatientData]}
              onChange={handleChange}
              placeholder={placeholder}
              required={required}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        ))}
      </div>

      <div className="space-y-1">
        <label htmlFor="symptoms" className="flex items-center text-sm font-medium text-gray-700">
          <FileText className="h-4 w-4 mr-2" />
          Symptoms Description
        </label>
        <textarea
          id="symptoms"
          name="symptoms"
          rows={4}
          value={formData.symptoms}
          onChange={handleChange}
          placeholder="Describe your symptoms in detail..."
          required
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      <div className="space-y-1">
        <label htmlFor="medicalHistory" className="flex items-center text-sm font-medium text-gray-700">
          <History className="h-4 w-4 mr-2" />
          Medical History
        </label>
        <textarea
          id="medicalHistory"
          name="medicalHistory"
          rows={3}
          value={formData.medicalHistory}
          onChange={handleChange}
          placeholder="Enter any relevant medical history..."
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      <button
        type="submit"
        className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        <Send className="h-4 w-4 mr-2" />
        Analyze Symptoms
      </button>
    </form>
  );
}