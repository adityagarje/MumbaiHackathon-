import React from 'react';
import { AlertCircle, Pill, Stethoscope } from 'lucide-react';

interface AnalysisProps {
  loading: boolean;
  result?: {
    condition: string;
    urgency: 'low' | 'medium' | 'high';
    recommendations: string[];
    medications?: string[];
  };
}

export function Analysis({ loading, result }: AnalysisProps) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!result) return null;

  const urgencyColors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800'
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 space-y-6">
      <div className="flex items-start space-x-4">
        <Stethoscope className="h-6 w-6 text-blue-600 mt-1" />
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Potential Condition</h3>
          <p className="mt-1 text-gray-600">{result.condition}</p>
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <AlertCircle className="h-5 w-5" />
        <span className={`px-2.5 py-0.5 rounded-full text-sm font-medium ${urgencyColors[result.urgency]}`}>
          {result.urgency.charAt(0).toUpperCase() + result.urgency.slice(1)} Urgency
        </span>
      </div>

      <div className="space-y-4">
        <div>
          <h4 className="text-md font-medium text-gray-900 mb-2">Recommendations</h4>
          <ul className="list-disc pl-5 space-y-1">
            {result.recommendations.map((rec, index) => (
              <li key={index} className="text-gray-600">{rec}</li>
            ))}
          </ul>
        </div>

        {result.medications && (
          <div>
            <h4 className="text-md font-medium text-gray-900 mb-2 flex items-center">
              <Pill className="h-4 w-4 mr-2" />
              Suggested Medications
            </h4>
            <ul className="list-disc pl-5 space-y-1">
              {result.medications.map((med, index) => (
                <li key={index} className="text-gray-600">{med}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}