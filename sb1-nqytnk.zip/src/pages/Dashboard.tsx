import React from 'react';
import { SymptomForm } from '../components/SymptomForm';
import { Analysis } from '../components/Analysis';
import { Disclaimer } from '../components/Disclaimer';
import { Chatbot } from '../components/Chatbot';
import { useAuth } from '../contexts/AuthContext';

export function Dashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = React.useState(false);
  const [analysis, setAnalysis] = React.useState(null);

  const handleSubmit = async (data: any) => {
    setLoading(true);
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...data, userId: user?._id }),
      });
      const result = await response.json();
      setAnalysis(result);
    } catch (error) {
      console.error('Error analyzing symptoms:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="max-w-3xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
      <Disclaimer />
      
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">
          Welcome, {user?.name}
        </h2>
        <SymptomForm onSubmit={handleSubmit} />
      </div>

      {(loading || analysis) && (
        <Analysis loading={loading} result={analysis} />
      )}

      <Chatbot apiKey="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" />
    </main>
  );
}