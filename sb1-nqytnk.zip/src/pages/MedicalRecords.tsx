import React, { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { api } from '../services/api';

interface MedicalRecord {
  _id: string;
  symptoms: string;
  diagnosis: string;
  recommendations: string[];
  createdAt: string;
}

export function MedicalRecords() {
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecords = async () => {
      try {
        const response = await api.get('/records');
        setRecords(response.data);
      } catch (error) {
        console.error('Error fetching records:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRecords();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-2xl font-bold mb-6">Medical Records</h2>
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {records.map((record) => (
            <li key={record._id} className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    Date: {format(new Date(record.createdAt), 'PPP')}
                  </p>
                  <p className="mt-2 text-sm text-gray-500">
                    Symptoms: {record.symptoms}
                  </p>
                  <p className="mt-2 text-sm text-gray-500">
                    Diagnosis: {record.diagnosis}
                  </p>
                </div>
              </div>
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900">Recommendations:</h4>
                <ul className="mt-2 text-sm text-gray-500 list-disc pl-5">
                  {record.recommendations.map((rec, index) => (
                    <li key={index}>{rec}</li>
                  ))}
                </ul>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}