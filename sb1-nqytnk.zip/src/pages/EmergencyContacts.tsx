import React, { useState, useEffect } from 'react';
import { Phone, Plus, Trash2 } from 'lucide-react';
import { api } from '../services/api';

interface EmergencyContact {
  _id: string;
  name: string;
  phone: string;
  relationship: string;
}

export function EmergencyContacts() {
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [newContact, setNewContact] = useState({ name: '', phone: '', relationship: '' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchContacts();
  }, []);

  const fetchContacts = async () => {
    try {
      const response = await api.get('/emergency-contacts');
      setContacts(response.data);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    } finally {
      setLoading(false);
    }
  };

  const addContact = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await api.post('/emergency-contacts', newContact);
      setContacts([...contacts, response.data]);
      setNewContact({ name: '', phone: '', relationship: '' });
    } catch (error) {
      console.error('Error adding contact:', error);
    }
  };

  const deleteContact = async (id: string) => {
    try {
      await api.delete(`/emergency-contacts/${id}`);
      setContacts(contacts.filter(contact => contact._id !== id));
    } catch (error) {
      console.error('Error deleting contact:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-2xl font-bold mb-6">Emergency Contacts</h2>
      
      <form onSubmit={addContact} className="bg-white p-6 rounded-lg shadow-sm mb-6">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
          <input
            type="text"
            value={newContact.name}
            onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
            placeholder="Contact Name"
            required
            className="px-3 py-2 border border-gray-300 rounded-md"
          />
          <input
            type="tel"
            value={newContact.phone}
            onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
            placeholder="Phone Number"
            required
            className="px-3 py-2 border border-gray-300 rounded-md"
          />
          <input
            type="text"
            value={newContact.relationship}
            onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
            placeholder="Relationship"
            required
            className="px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>
        <button
          type="submit"
          className="mt-4 flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Contact
        </button>
      </form>

      <div className="bg-white rounded-lg shadow">
        <ul className="divide-y divide-gray-200">
          {contacts.map((contact) => (
            <li key={contact._id} className="p-4 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium">{contact.name}</h3>
                <p className="text-gray-500">{contact.relationship}</p>
                <div className="flex items-center mt-1 text-gray-600">
                  <Phone className="h-4 w-4 mr-2" />
                  {contact.phone}
                </div>
              </div>
              <button
                onClick={() => deleteContact(contact._id)}
                className="text-red-600 hover:text-red-800"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}