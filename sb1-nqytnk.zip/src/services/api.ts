import axios from 'axios';

export const api = axios.create({
  baseURL: '/api',
});

// Add chat endpoint
api.chat = async (message: string, language: string = 'en') => {
  try {
    const response = await api.post('/chat', {
      message,
      language,
    });
    return response.data;
  } catch (error) {
    console.error('Chat API Error:', error);
    throw error;
  }
};

api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);